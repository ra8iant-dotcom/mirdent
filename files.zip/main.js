/**
 * MIRDENT MULTI-SPECIALITY DENTAL CARE
 * Main JavaScript
 * =====================================================
 * Features:
 *   1. Sticky header behaviour
 *   2. Mobile navigation
 *   3. Smooth scrolling active link tracking
 *   4. Scroll reveal animations
 *   5. FAQ accordion
 *   6. Appointment form validation & submission
 *   7. Scroll-to-top button
 *   8. Footer year auto-update
 *   9. Lazy image loading
 */

/* =====================================================
   DOMContentLoaded — Entry Point
   ===================================================== */
document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initMobileNav();
  initScrollReveal();
  initFAQ();
  initAppointmentForm();
  initScrollTop();
  initFooterYear();
  initLazyImages();
  setMinDate();
});

/* =====================================================
   1. STICKY HEADER BEHAVIOUR
   Adds .scrolled class when user scrolls past 40px
   ===================================================== */
function initHeader() {
  const header = document.getElementById('site-header');
  if (!header) return;

  function onScroll() {
    header.classList.toggle('scrolled', window.scrollY > 40);
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll(); // run on load in case of refresh mid-page
}

/* =====================================================
   2. MOBILE NAVIGATION TOGGLE
   ===================================================== */
function initMobileNav() {
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileLinks = document.querySelectorAll('.mobile-link, .mobile-link-cta');

  if (!hamburger || !mobileMenu) return;

  function openMenu() {
    hamburger.classList.add('open');
    mobileMenu.classList.add('open');
    hamburger.setAttribute('aria-expanded', 'true');
    mobileMenu.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    hamburger.classList.remove('open');
    mobileMenu.classList.remove('open');
    hamburger.setAttribute('aria-expanded', 'false');
    mobileMenu.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  hamburger.addEventListener('click', () => {
    hamburger.classList.contains('open') ? closeMenu() : openMenu();
  });

  // Close when any nav link is clicked
  mobileLinks.forEach(link => link.addEventListener('click', closeMenu));

  // Close when clicking outside
  document.addEventListener('click', (e) => {
    if (
      mobileMenu.classList.contains('open') &&
      !mobileMenu.contains(e.target) &&
      !hamburger.contains(e.target)
    ) {
      closeMenu();
    }
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mobileMenu.classList.contains('open')) {
      closeMenu();
      hamburger.focus();
    }
  });
}

/* =====================================================
   3. SCROLL REVEAL ANIMATIONS
   Uses IntersectionObserver for performance
   ===================================================== */
function initScrollReveal() {
  const revealEls = document.querySelectorAll('.reveal');
  if (!revealEls.length) return;

  // Fallback for browsers without IntersectionObserver
  if (!('IntersectionObserver' in window)) {
    revealEls.forEach(el => el.classList.add('revealed'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target); // only animate once
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -40px 0px'
  });

  revealEls.forEach(el => observer.observe(el));
}

/* =====================================================
   4. FAQ ACCORDION
   Accessible: updates aria-expanded, toggles hidden attr
   ===================================================== */
function initFAQ() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const btn = item.querySelector('.faq-question');
    const answerId = btn.getAttribute('aria-controls');
    const answer = document.getElementById(answerId);

    if (!btn || !answer) return;

    btn.addEventListener('click', () => {
      const isExpanded = btn.getAttribute('aria-expanded') === 'true';

      // Close ALL other FAQ items (accordion behaviour)
      faqItems.forEach(otherItem => {
        const otherBtn = otherItem.querySelector('.faq-question');
        const otherAnswerId = otherBtn?.getAttribute('aria-controls');
        const otherAnswer = otherAnswerId ? document.getElementById(otherAnswerId) : null;
        if (otherBtn && otherAnswer && otherItem !== item) {
          otherBtn.setAttribute('aria-expanded', 'false');
          otherAnswer.hidden = true;
        }
      });

      // Toggle this item
      if (isExpanded) {
        btn.setAttribute('aria-expanded', 'false');
        answer.hidden = true;
      } else {
        btn.setAttribute('aria-expanded', 'true');
        answer.hidden = false;
      }
    });
  });
}

/* =====================================================
   5. APPOINTMENT FORM VALIDATION & SUBMISSION
   Validates required fields, submits to Formspree
   ===================================================== */
function initAppointmentForm() {
  const form = document.getElementById('appointment-form');
  if (!form) return;

  const submitBtn = document.getElementById('submit-btn');
  const submitText = document.getElementById('submit-text');
  const submitLoading = document.getElementById('submit-loading');
  const successMsg = document.getElementById('form-success');
  const errorMsg = document.getElementById('form-error-msg');

  // --- Field Validators ---
  const validators = {
    name: (val) => {
      if (!val.trim()) return 'Please enter your full name.';
      if (val.trim().length < 2) return 'Name must be at least 2 characters.';
      return '';
    },
    phone: (val) => {
      // Accepts Indian mobile numbers with optional +91, spaces, or dashes
      const cleaned = val.replace(/[\s\-\(\)]/g, '');
      if (!cleaned) return 'Please enter your phone number.';
      if (!/^(\+91|91)?[6-9]\d{9}$/.test(cleaned)) return 'Please enter a valid Indian mobile number.';
      return '';
    },
    service: (val) => {
      if (!val) return 'Please select a service.';
      return '';
    }
  };

  // Show or clear an error on a field
  function setFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errorEl = document.getElementById(`${fieldId}-error`);
    if (!field || !errorEl) return;

    if (message) {
      field.classList.add('error');
      errorEl.textContent = message;
    } else {
      field.classList.remove('error');
      errorEl.textContent = '';
    }
  }

  // Validate a single field
  function validateField(id) {
    if (!validators[id]) return true;
    const field = document.getElementById(id);
    if (!field) return true;
    const error = validators[id](field.value);
    setFieldError(id, error);
    return !error;
  }

  // Live validation on blur
  ['name', 'phone', 'service'].forEach(id => {
    const field = document.getElementById(id);
    if (field) {
      field.addEventListener('blur', () => validateField(id));
      field.addEventListener('input', () => {
        if (field.classList.contains('error')) validateField(id);
      });
    }
  });

  // Validate all required fields
  function validateForm() {
    const nameOk = validateField('name');
    const phoneOk = validateField('phone');
    const serviceOk = validateField('service');
    return nameOk && phoneOk && serviceOk;
  }

  // Form submit handler
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Reset messages
    successMsg.style.display = 'none';
    errorMsg.style.display = 'none';

    if (!validateForm()) return; // stop if validation fails

    // Show loading state
    submitBtn.disabled = true;
    submitText.style.display = 'none';
    submitLoading.style.display = 'inline';

    try {
      const response = await fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'Accept': 'application/json' }
      });

      if (response.ok) {
        // Success
        form.reset();
        successMsg.style.display = 'block';
        successMsg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

        // Track conversion (if Google Analytics is installed)
        if (typeof gtag === 'function') {
          gtag('event', 'appointment_form_submit', {
            event_category: 'engagement',
            event_label: 'Appointment Booking'
          });
        }
      } else {
        const data = await response.json();
        if (data.errors) {
          errorMsg.textContent = data.errors.map(e => e.message).join(', ');
        }
        errorMsg.style.display = 'block';
      }
    } catch (err) {
      console.error('Form submission error:', err);
      errorMsg.style.display = 'block';
    } finally {
      submitBtn.disabled = false;
      submitText.style.display = 'inline';
      submitLoading.style.display = 'none';
    }
  });
}

/* =====================================================
   6. SCROLL TO TOP BUTTON
   ===================================================== */
function initScrollTop() {
  const btn = document.getElementById('scroll-top');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* =====================================================
   7. FOOTER YEAR — ALWAYS SHOWS CURRENT YEAR
   ===================================================== */
function initFooterYear() {
  const el = document.getElementById('footer-year');
  if (el) el.textContent = new Date().getFullYear();
}

/* =====================================================
   8. LAZY IMAGE LOADING
   Native lazy loading + Intersection Observer fallback
   ===================================================== */
function initLazyImages() {
  const imgs = document.querySelectorAll('img[data-src]');
  if (!imgs.length) return;

  if ('loading' in HTMLImageElement.prototype) {
    imgs.forEach(img => {
      img.src = img.dataset.src;
      img.removeAttribute('data-src');
    });
  } else if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          observer.unobserve(img);
        }
      });
    }, { rootMargin: '200px' });

    imgs.forEach(img => observer.observe(img));
  } else {
    imgs.forEach(img => { img.src = img.dataset.src; });
  }
}

/* =====================================================
   9. SET MINIMUM DATE ON APPOINTMENT DATE INPUT
   Prevents booking in the past
   ===================================================== */
function setMinDate() {
  const dateInput = document.getElementById('date');
  if (!dateInput) return;

  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const dd = String(today.getDate()).padStart(2, '0');
  dateInput.min = `${yyyy}-${mm}-${dd}`;
}

/* =====================================================
   10. ACTIVE NAV LINK ON SCROLL
   Highlights the nav item matching the visible section
   ===================================================== */
(function initActiveNav() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-links a[href^="#"]');
  if (!sections.length || !navLinks.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        navLinks.forEach(link => {
          link.style.color = '';
          link.style.background = '';
          if (link.getAttribute('href') === `#${id}`) {
            link.style.color = 'var(--color-primary)';
            link.style.background = 'var(--color-primary-light)';
          }
        });
      }
    });
  }, {
    rootMargin: `-${parseInt(getComputedStyle(document.documentElement).getPropertyValue('--header-height') || '72')}px 0px -60% 0px`,
    threshold: 0
  });

  sections.forEach(section => observer.observe(section));
})();
