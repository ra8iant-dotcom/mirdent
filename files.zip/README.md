# Mirdent Multi-speciality Dental Care — Website

**A complete, production-ready website for a premium dental clinic in Mira Road East, Mumbai.**

---

## 📁 Folder Structure

```
mirdent/
├── index.html              ← Main website (all pages are sections in this file)
├── css/
│   └── style.css           ← All styles (CSS variables, responsive, animations)
├── js/
│   └── main.js             ← All JavaScript (nav, form, animations, FAQ)
├── images/                 ← Place your clinic photos here (see list below)
│   ├── favicon.png         ← 32×32 px browser tab icon
│   ├── og-image.jpg        ← 1200×630 px Open Graph / social sharing image
│   ├── hero-doctor.jpg     ← 800×700 px — Hero section photo (doctor or smiling patient)
│   ├── clinic-interior.jpg ← 700×550 px — About section (reception / treatment room)
│   ├── clinic-front.jpg    ← 600×450 px — Clinic exterior
│   ├── gallery-1.jpg       ← 900×560 px — Gallery item (reception)
│   ├── gallery-2.jpg       ← 600×450 px — Gallery item (treatment room)
│   ├── gallery-3.jpg       ← 600×450 px — Gallery item (equipment)
│   ├── gallery-4.jpg       ← 600×450 px — Gallery item (waiting area)
│   ├── gallery-5.jpg       ← 600×450 px — Gallery item (doctor with patient)
│   └── gallery-6.jpg       ← 600×450 px — Gallery item (clinic exterior)
└── README.md               ← This file
```

---

## 🚀 Quick Start (Local Development)

No build tools required — this is plain HTML, CSS, and JavaScript.

**Option A — Open directly:**
```bash
# Just open the file in your browser
open index.html
```

**Option B — Use a local server (recommended to avoid CORS issues with the map):**
```bash
# If you have Python 3:
cd mirdent
python3 -m http.server 3000
# Then open: http://localhost:3000

# If you have Node.js:
npx serve .
# Then open: http://localhost:3000
```

---

## ✅ Customisation Checklist

### 1. IMAGES — Replace All Placeholders
Search for `<!-- REPLACE:` or `📷 Replace` in index.html to find all image slots.

**How to add images:**
```html
<!-- Hero section — replace the placeholder div with: -->
<img
  src="images/hero-doctor.jpg"
  alt="Dr. [Name] at Mirdent Dental Clinic"
  width="800" height="700"
  loading="eager"
/>

<!-- About section — replace the placeholder div with: -->
<img
  src="images/clinic-interior.jpg"
  alt="Mirdent clinic interior"
  width="700" height="550"
  loading="lazy"
/>

<!-- Gallery items — replace each placeholder div with: -->
<img
  src="images/gallery-1.jpg"
  alt="Mirdent reception area"
  width="900" height="560"
  loading="lazy"
/>
```

**Photo tips:**
- Use WebP format for best performance (convert with squoosh.app)
- Compress all images to under 200KB each
- Use descriptive alt text for SEO

---

### 2. APPOINTMENT FORM — Connect to Formspree (FREE)

1. Go to **https://formspree.io** and create a free account
2. Click **+ New Form**, give it a name like "Mirdent Appointment"
3. Copy your form endpoint — it looks like: `https://formspree.io/f/xyzabcde`
4. Open `index.html` and find this line:
   ```html
   action="https://formspree.io/f/YOUR_FORM_ID"
   ```
5. Replace `YOUR_FORM_ID` with your actual ID:
   ```html
   action="https://formspree.io/f/xyzabcde"
   ```
6. Formspree will email you every new appointment request.

**Alternative — Netlify Forms (if hosting on Netlify):**
Add `netlify` attribute to the form tag and a hidden input:
```html
<form netlify name="appointment" ...>
  <input type="hidden" name="form-name" value="appointment" />
  ...
</form>
```

---

### 3. GOOGLE MAPS EMBED — Update Your Location

1. Go to **https://maps.google.com**
2. Search for: `Mirdent Multi-speciality Dental Care, Mira Road East`
3. Click **Share** → **Embed a map** → Copy the `<iframe>` HTML
4. In `index.html`, find the `<iframe>` inside the contact section
5. Replace the `src` attribute value with your copied embed URL

---

### 4. GOOGLE REVIEWS LINK

Find this line in index.html:
```html
href="https://g.page/r/your-google-place-id/review"
```
Replace with your actual Google Business review link:
1. Go to your Google Business Profile
2. Click **Get more reviews** → Copy the link shown
3. Paste it in the href above

---

### 5. SOCIAL MEDIA LINKS

Find the footer social links and update the `href` values:
```html
<a href="https://facebook.com/mirdent" ...>       ← Update with your Facebook page
<a href="https://instagram.com/mirdent" ...>      ← Update with your Instagram handle
```

---

### 6. GOOGLE ANALYTICS (Optional)

To track website visitors, add this just before `</head>` in index.html:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX'); // Replace with your Measurement ID
</script>
```

---

## 🌐 Deployment Instructions

### Deploy to Netlify (Recommended — Free)

1. Go to **https://netlify.com** and sign up (free)
2. Click **Add new site** → **Deploy manually**
3. Drag and drop your entire `mirdent/` folder into the deploy window
4. Your site goes live instantly with a URL like `https://mirdent.netlify.app`

**Or with Netlify CLI:**
```bash
npm install -g netlify-cli
cd mirdent
netlify deploy --prod
```

---

### Deploy to Vercel (Also Free)

1. Go to **https://vercel.com** and sign up
2. Install Vercel CLI: `npm install -g vercel`
3. In the `mirdent/` folder, run:
   ```bash
   vercel --prod
   ```
4. Follow the prompts. Your site will be live at `https://mirdent.vercel.app`

---

### Deploy to GitHub Pages (Also Free)

1. Create a GitHub account at **https://github.com**
2. Create a new repository named `mirdent`
3. Upload all files to the repository
4. Go to **Settings → Pages → Source → Deploy from a branch → main / root**
5. Your site will be at `https://yourusername.github.io/mirdent/`

---

## 🔗 Custom Domain Setup

### On Netlify:
1. Go to your site in the Netlify dashboard
2. Click **Domain settings** → **Add custom domain**
3. Enter your domain (e.g. `mirdent.in`)
4. Follow DNS instructions shown — you'll need to add CNAME or A records at your domain registrar
5. Netlify provides free SSL automatically

### On Vercel:
1. Go to your project → **Settings → Domains**
2. Add your domain (e.g. `mirdent.in`)
3. Follow the DNS configuration shown
4. Free SSL is provisioned automatically

### DNS Records to Add (at your domain registrar):
```
Type   Host   Value
A      @      76.76.21.21     (Vercel) OR 75.2.60.5 (Netlify)
CNAME  www    cname.vercel-dns.com  (Vercel) OR your-site.netlify.app (Netlify)
```

---

## 🔍 SEO Checklist Before Launch

- [ ] Replace all placeholder images with real clinic photos
- [ ] Update the Google Maps embed with real clinic location
- [ ] Add favicon.png (32×32px) in the images/ folder
- [ ] Add og-image.jpg (1200×630px) for social sharing
- [ ] Update the canonical URL: `<link rel="canonical" href="https://YOUR-DOMAIN.com/" />`
- [ ] Update Open Graph URL: `<meta property="og:url" content="https://YOUR-DOMAIN.com/" />`
- [ ] Update Schema.org geo coordinates with real lat/lng
- [ ] Connect Google Search Console after deployment
- [ ] Submit your sitemap (Netlify/Vercel generate one automatically)
- [ ] Set up Google Analytics or Plausible analytics

---

## 📞 Support & Maintenance

**To update business hours:**
Find the `<!-- BUSINESS HOURS -->` section in index.html and update the table.

**To add new services:**
Copy an existing `<article class="service-card">` block and update the emoji, title, description, and price.

**To update the doctor's name or team:**
Search for "doctor" in index.html and update the relevant sections.

**To change colours:**
All colours are in `css/style.css` at the top under `:root { }`.
Change `--color-primary` and `--color-secondary` to match your brand.

---

## 📋 Tech Stack

| Technology | Usage |
|---|---|
| HTML5 (semantic) | Page structure, SEO, accessibility |
| CSS3 (custom properties) | All styling, responsive design, animations |
| Vanilla JavaScript (ES6+) | Navigation, FAQ, form validation, scroll effects |
| Google Fonts | Playfair Display + DM Sans |
| Formspree | Form submissions (no backend needed) |
| IntersectionObserver API | Scroll animations & lazy loading |

**No build tools, no frameworks, no npm required.**
Drop the folder on Netlify and it works.

---

*Built for Mirdent Multi-speciality Dental Care, Mira Road East, Mumbai.*
